let data={};
const loadData=()=>{
   var data_script = document.querySelector("#data_script");
   data={
     address,url,last_order,payment_id
   }
   data_script.remove();
}