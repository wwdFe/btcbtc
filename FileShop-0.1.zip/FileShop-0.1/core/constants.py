from babel.numbers import list_currencies

CURRENCY_CHOICES = [(CURRENCY, CURRENCY) for CURRENCY in list_currencies()]
